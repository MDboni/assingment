const SendEmail=async(EmailTo,EmailText,EmailSubject)=>{



}


export default SendEmail;